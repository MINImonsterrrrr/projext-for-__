# Investment Portfolio Manager

A working frontend prototype based on the SRS screenshot.

Included:
- Login and registration
- Dashboard
- Portfolio
- Add investment
- Purchase/sale transactions
- Reports and summaries
- Asset allocation
- Portfolio performance chart
- Form validation
- Browser localStorage persistence

Run:
Open `index.html` in a browser. No server is required for this prototype.

Demo:
Create an account from the Registration page, then log in and add investments.
