# Ledger — Investment Portfolio Manager

A self-contained frontend prototype for tracking a personal investment
portfolio. No build step, no server, no dependencies beyond a browser.

## Run it
Open `index.html` directly in a browser (double-click it, or File → Open).
Everything is stored in that browser's `localStorage`.

## What's included
- Account creation and login, with passwords stored as a salted SHA-256
  hash rather than plain text (still a client-side demo, not real security —
  a production version needs a real backend)
- Dashboard with a real performance chart built from a snapshot taken every
  time your holdings change, not placeholder data
- Portfolio table: search, sortable columns, inline edit and delete per
  holding
- Add investment, with current price defaulting to purchase price
- Transactions: purchases update your holding using a weighted-average
  purchase price; sales are capped at what you actually hold. Transaction
  history itself is immutable, like a real ledger — mistakes are corrected
  with a new entry, not by rewriting history
- Reports page with a CSV export of your holdings
- Asset allocation as a proportional bar + legend
- "Explore with sample data" on the login screen — loads a demo account
  with 10 sample holdings (two each of Stock, Mutual Fund, ETF, Bond and
  Crypto, each with its own quantity and price) so you can see the app
  populated without creating your own account
- Confirmation dialogs before destructive actions, toast notifications,
  keyboard-accessible focus states, and a layout that collapses to a
  narrow sidebar and single-column forms on mobile

## Known limitations (by design, for a prototype)
- Data lives only in one browser's localStorage — clearing site data
  or switching browsers loses it
- No real backend, so "security" here is best-effort, not production-grade
- Prices are entered manually; there's no live market data feed
